package com.company;

public enum MagicalAttack {
    Expelliarmus,
    Akcio,
    ExpectoPatronum;

}
